<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'body',
    'as' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'body',
    'as' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$variants = [
    'title' => 'text-2xl font-bold text-gray-900 dark:text-white',
    'subtitle' => 'text-lg font-bold text-gray-900 dark:text-white',
    'heading' => 'text-lg font-semibold text-gray-900 dark:text-white',
    'label' => 'block text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400',
    'body' => 'text-sm text-gray-900 dark:text-white',
    'muted' => 'text-sm text-gray-500 dark:text-gray-400',
];

$classes = $variants[$variant] ?? $variants['body'];

if (! $as) {
    if ($variant === 'title') {
        $as = 'h1';
    } elseif (in_array($variant, ['subtitle', 'heading'])) {
        $as = 'h2';
    } elseif ($variant === 'label') {
        $as = 'label';
    } else {
        $as = 'p';
    }
}
?>

<<?php echo e($as); ?> <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</<?php echo e($as); ?>>
<?php /**PATH /Users/riveroo/project/laravel/Konveksi/resources/views/components/text.blade.php ENDPATH**/ ?>