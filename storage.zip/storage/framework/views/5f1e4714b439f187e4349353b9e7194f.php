<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KonveksiHub</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased font-sans bg-gray-50 text-gray-900 min-h-screen flex flex-col">
    <!-- Navbar -->
    <header class="bg-white shadow relative z-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold flex items-center gap-2 text-indigo-600">
                <svg class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 4.5H8.25L3 9.75v10.5h18V9.75L15.75 4.5z M15.75 4.5v1.5a3.75 3.75 0 01-7.5 0V4.5" />
                </svg>
                KonveksiHub
            </h1>
            <nav class="flex gap-4 items-center">
                <a href="<?php echo e(route('products.index')); ?>" class="font-medium text-gray-600 hover:text-indigo-500">Products</a>
                <a href="<?php echo e(route('cart.index')); ?>" class="relative inline-flex items-center text-gray-600 hover:text-indigo-500">
                    <svg class="w-6 h-6 border-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count(session('cart', [])) > 0): ?>
                        <span class="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold px-1 rounded-full min-w-[16px] h-4 flex items-center justify-center"><?php echo e(count(session('cart', []))); ?></span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/admin')); ?>" class="font-medium text-gray-600 hover:text-indigo-500">Admin</a>
                <?php else: ?>
                    <a href="<?php echo e(url('/admin/login')); ?>" class="font-medium text-gray-600 hover:text-indigo-500">Login</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <main class="relative flex flex-grow items-center justify-center overflow-hidden min-h-[80vh] bg-gradient-to-br from-indigo-50 via-white to-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 py-16">
            <div class="inline-flex items-center gap-2 mb-6 px-4 py-2 bg-indigo-100/50 text-indigo-800 rounded-full text-sm font-semibold tracking-wide uppercase shadow-sm">
                Custom Clothing Made Easy
            </div>
            
            <h1 class="text-gray-900 text-5xl md:text-6xl mb-6 drop-shadow-sm font-bold">
                Crafted specifically for <span class="text-indigo-600">Your Brand</span>
            </h1>
            <p class="mt-4 text-xl md:text-2xl text-gray-500 max-w-3xl mx-auto mb-10 leading-relaxed font-medium">
                Design and manufacture high-quality apparel tailored exactly to your unique specifications. Build your next standout collection with us today.
            </p>
            <div class="flex items-center justify-center gap-4">
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('products.index')).'','variant' => 'indigo','size' => 'lg','class' => 'px-8 py-4 rounded-2xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('products.index')).'','variant' => 'indigo','size' => 'lg','class' => 'px-8 py-4 rounded-2xl']); ?>
                    View Our Collection
                    <svg class="ml-2 w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                      <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            </div>
        </div>
    </main>
    
    <footer class="bg-white border-t border-gray-200 py-8 text-center text-gray-500 text-sm">
        <div class="max-w-7xl mx-auto px-4">
            &copy; 2026 KonveksiHub. All rights reserved.
        </div>
    </footer>
</body>
</html>
<?php /**PATH /Users/riveroo/project/laravel/Konveksi/resources/views/welcome.blade.php ENDPATH**/ ?>