<!-- Header Component -->
<header 
    x-data="{ scrolled: false, mobileMenu: false }" 
    @scroll.window="scrolled = (window.pageYOffset > 50)"
    class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4"
    :class="scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm border-b border-gray-200 py-3' : 'bg-transparent py-6'"
>
    <!-- Background placeholder for non-landing pages when not scrolled -->
    <div 
        class="absolute inset-0 -z-10 transition-opacity duration-300" 
        :class="scrolled || !window.location.pathname.match(/^\/?$/) ? 'opacity-100 bg-white' : 'opacity-0'"
    ></div>

    <div class="container mx-auto px-6 flex items-center justify-between">
        <!-- Logo -->
        <a href="<?php echo e(url('/')); ?>" class="flex items-center gap-2 group">
            <div class="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl transition-transform group-hover:scale-110 shadow-lg shadow-indigo-600/20">
                K
            </div>
            <span class="font-outfit text-xl font-black tracking-tight transition-colors" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-900' : 'text-white'">
                Konveksi <span class="text-indigo-500">hub</span>
            </span>
        </a>

        <!-- Desktop Nav -->
        <nav class="hidden lg:flex items-center gap-8 text-sm font-semibold tracking-wide uppercase">
            <a href="<?php echo e(url('/')); ?>#beranda" class="transition-colors hover:text-indigo-500" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600' : 'text-slate-200'">Beranda</a>
            <a href="<?php echo e(url('/')); ?>#layanan" class="transition-colors hover:text-indigo-500" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600' : 'text-slate-200'">Layanan</a>
            <a href="<?php echo e(url('/')); ?>#portofolio" class="transition-colors hover:text-indigo-500" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600' : 'text-slate-200'">Portofolio</a>
            <a href="<?php echo e(url('/')); ?>#tentang" class="transition-colors hover:text-indigo-500" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600' : 'text-slate-200'">Tentang Kami</a>
            <a href="#kontak" class="transition-colors hover:text-indigo-500" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600' : 'text-slate-200'">Kontak</a>
        </nav>

        <div class="flex items-center gap-4">
            <!-- Cart Button (Visible on all pages) -->
            <a href="<?php echo e(route('cart.index')); ?>" class="relative p-2 transition-colors" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-600 hover:text-indigo-500' : 'text-white hover:text-indigo-300'">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path>
                </svg>
                <?php $cartCount = count(session('cart', [])); ?>
                <span x-show="<?php echo e($cartCount); ?> > 0" class="absolute top-0 right-0 bg-rose-500 text-white text-[10px] font-bold px-1 rounded-full min-w-[16px] h-4 flex items-center justify-center">
                    <?php echo e($cartCount); ?>

                </span>
            </a>

            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'indigo','href' => ''.e(route('public.stock')).'','class' => 'hidden sm:inline-flex rounded-full px-6 shadow-xl shadow-indigo-600/20']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'indigo','href' => ''.e(route('public.stock')).'','class' => 'hidden sm:inline-flex rounded-full px-6 shadow-xl shadow-indigo-600/20']); ?>
                CEK STOCK
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
            
            <button @click="mobileMenu = true" class="lg:hidden p-2 rounded-lg transition-colors" :class="(scrolled || !window.location.pathname.match(/^\/?$/)) ? 'text-slate-900 hover:bg-slate-100' : 'text-white hover:bg-white/10'">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
            </button>
        </div>
    </div>

    <!-- Mobile Menu Overlay -->
    <div x-cloak x-show="mobileMenu" 
        x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-x-full"
        x-transition:enter-end="opacity-100 translate-x-0"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100 translate-x-0"
        x-transition:leave-end="opacity-0 translate-x-full"
        class="fixed inset-0 z-[60] bg-white lg:hidden flex flex-col p-8"
    >
        <div class="flex items-center justify-between mb-12">
            <span class="font-outfit text-2xl font-black tracking-tight">Konveksi <span class="text-indigo-500">hub</span></span>
            <button @click="mobileMenu = false" class="p-2 text-slate-400 hover:text-slate-900">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <nav class="flex flex-col gap-6 text-2xl font-bold font-outfit">
            <a href="<?php echo e(url('/')); ?>#beranda" @click="mobileMenu = false" class="hover:text-indigo-600">Beranda</a>
            <a href="<?php echo e(url('/')); ?>#layanan" @click="mobileMenu = false" class="hover:text-indigo-600">Layanan</a>
            <a href="<?php echo e(url('/')); ?>#portofolio" @click="mobileMenu = false" class="hover:text-indigo-600">Portofolio</a>
            <a href="<?php echo e(url('/')); ?>#tentang" @click="mobileMenu = false" class="hover:text-indigo-600">Tentang Kami</a>
            <a href="#kontak" @click="mobileMenu = false" class="hover:text-indigo-600">Kontak</a>
        </nav>
        <div class="mt-auto">
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'indigo','href' => ''.e(route('public.stock')).'','class' => 'w-full py-4 rounded-2xl text-lg','@click' => 'mobileMenu = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'indigo','href' => ''.e(route('public.stock')).'','class' => 'w-full py-4 rounded-2xl text-lg','@click' => 'mobileMenu = false']); ?>
                CEK STOCK
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH /Users/riveroo/project/laravel/Konveksi/resources/views/components/layouts/header.blade.php ENDPATH**/ ?>